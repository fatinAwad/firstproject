#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "definitions.h"
#include "helpFuncs.h"
#include "login.h"
#include "profile.h"

// Free Allocated Memory Macro
#define FREE_ALLOC_MEM() \
		free(name);\
		name=NULL;\
		free(pass);\
		pass=NULL;\
		free(encryptedPass);\
		encryptedPass=NULL

//external variables
extern account_t *head;

//extern Functions
extern UINT fromBinary(char *s);
extern bool_t checkPasswordValidity(char *pass);

void loginFunc(void)
{
	login_t loginTry;
	loginTry_t threeAttempts;
	char flag=0;
	char *nameAndPass;
	account_t *tmp=head;
	while(1){
		flag=0;
		printf("\nPlease enter your username and password in the format: \'username::password\'.\n");
		printf("To go back to the first screen enter \'#\'\n");
		printf("To exit the app please enter \'$\'.\n");
		printf("\nInput : ");
		nameAndPass = getString();
		printf("\n\n=========================================================================\n\n\n");
		if (!strcmp(nameAndPass,"$")){
			free(nameAndPass);
			nameAndPass=NULL;
			exitFunc();
		}
		else if(!strcmp(nameAndPass,"#"))
			return ;
		else{
			loginTry=loginValidation(nameAndPass);
			switch (loginTry){
				case WRONG_PASS:
								printf("Dear %s, you have entered a wrong password.\n Please choose one of the following options:\n",nameAndPass);
								threeAttempts=wrongPassEntryMenu(nameAndPass);
								if(threeAttempts==THREE_ATTEMPS)
								{
									free(nameAndPass);
									nameAndPass=NULL;
									exitFunc();
								}
								else if(threeAttempts==BACK_TO_MAIN)
								{
									free(nameAndPass);
									nameAndPass=NULL;
									return ;
								}
								else
								{
									newPasswordEntry();
								}
								flag=1;
								break;
				case BAD_INPUT_SYNTAX: 
								printf("\n\nDear guest, please enter your username and password in the following way:username::password.\n");
								printf("Username does not exist in our memory banks. Please try again.\n\n");
								break;
				case RIGHT_PASS: 
								profileMenu();
								return;
								break;
				case AACOUNT_NOT_EXIST:
								printf("Username does not exist in our memory banks. Please try again.\n\n");
								break;
				case PASS_LENGTH_ERROR:
								printf("Wrong Password, Try Again\n");
								break;
			}
			if(flag==1)
				break;
		}
		printf("\n\n=========================================================================\n\n\n");
	}
		
}


login_t loginValidation(char *accountNameAndPass){
	account_t *tmp=head;
	char *pch=NULL;
	char *name=NULL;
	char *pass=NULL;
	char *tmpAccountNameAndPass=NULL;
	char *encryptedPass=NULL;
	UINT i=0;
	tmpAccountNameAndPass=accountNameAndPass;
	pch = strtok(tmpAccountNameAndPass, ":");
	if (pch==NULL)
		return BAD_INPUT_SYNTAX;
	name=(char*)malloc(strlen(pch)+1);
	strcpy(name,pch);
	pch = strtok(NULL, ":");
	if (pch==NULL){
		FREE_ALLOC_MEM();
		return BAD_INPUT_SYNTAX;
	}
	pass=(char*)malloc(strlen(pch)+1);
	strcpy(pass,pch);
	while(tmp!=NULL){
		encryptedPass=getEncryptedPass(pass,tmp->randNum);
		//only for debugging
		//printf("\n\n\n---------Name: %s , Pass: %s--------- , encryptPass: %s\n\n\n",name,pass,encryptedPass);
		//printf("\n\nThe Name Is : %s, The Pass Is : %s, randNum Is : %s\n",tmp->name,tmp->password,tmp->randNum);
		if(strcmp(tmp->name,name)==0){
			loginAccount=tmp;
			if(encryptedPass==NULL){
				FREE_ALLOC_MEM();
				return PASS_LENGTH_ERROR;
			}
			if(strcmp(tmp->password,encryptedPass)==0){
				FREE_ALLOC_MEM();
				return RIGHT_PASS;
			}
			FREE_ALLOC_MEM();
			return WRONG_PASS;
		}
		tmp=tmp->next;
	}
	FREE_ALLOC_MEM();
	return AACOUNT_NOT_EXIST;
}




loginTry_t wrongPassEntryMenu(char *nameAndPass)
{
	int count;
	char choiceSecretQMenu;
	login_t loginTry;
	char i;
	char *newPass=NULL;
	char *newAccountAndPass=NULL;
	char *ansSecrectQues=NULL;
	int length;
	//printf("\n\n=========================================================================\n\n\n");
	while (1)
	{
		count=3;
		printLoginWrongPassMenu();
		printf("\nInput : ");
		scanf(" %c",&i);
		printf("\n\n=========================================================================\n\n\n");
		if (i=='1'){
			printf("\nEnter The Password Again.\n");
			printf("\nInput : ");
			newPass=getString();
			length = strlen(loginAccount->name)+strlen(newPass)+3;
			newAccountAndPass=(char *)malloc(length);
			strcpy(newAccountAndPass,loginAccount->name);
			strcat(newAccountAndPass,"::");
			strcat(newAccountAndPass,newPass);
			loginTry=loginValidation(newAccountAndPass);
			if(loginTry==RIGHT_PASS){
				free(newPass);
				newPass=NULL;
				free(newAccountAndPass);
				newAccountAndPass=NULL;
				profileMenu();
				return;
			}
			else{
				free(newAccountAndPass);
				newAccountAndPass=NULL;
				free(newPass);
				newPass=NULL;
				continue;
			}
		}
		else if(i=='!'){
			while(count!=0){
			//	printf("\n\n=========================================================================\n\n\n");
		//		printf("What Do You Want To Do Next ?!\n\n");
				printf("Question: Where did you perform your last air guitar jam?!\n");
				printf("#-Back To The Main Menu\n");
				printf("$-Exit The Program\n");
				printf("\nInput : ");
					ansSecrectQues=getString();
		//		scanf(" %c",&choiceSecretQMenu);
				if(ansSecrectQues[0]=='#' && ansSecrectQues[1] == '\0')
				{
					return BACK_TO_MAIN;
				}
				else if(ansSecrectQues[0]=='$' && ansSecrectQues[1] == '\0')
				{
					exitFunc();
				}
				else
					// if(choiceSecretQMenu=='1')
				{			
		//			printf("\n\n=========================================================================\n\n\n");
			//		printf("Question: Where did you perform your last air guitar jam?!\n");
				//	printf("\nInput : ");
				//	ansSecrectQues=getString();
					//printf("\n\n\n************************************************\n\n\n");
					//printf("secret Answer : \'%s\'  , you entered: \'%s\'\n",ansSecrectQues,loginAccount->securityAns);
					//printf("\n\n\n************************************************\n\n\n");
					if(strcmp(ansSecrectQues,loginAccount->securityAns)==0)
					{
						free(ansSecrectQues);
						ansSecrectQues=NULL;
						return NEW_PASS;
					}
					else{
						if(count != 1)
						{
						printf("\nDear %s, you have entered a wrong answer, please try again.\n",nameAndPass);
						}
						
						
				
						
						count--;
					}

				}
			}

			if(count==0)
			{

			printf("\nDear %s, you failed to enter the correct answer 3 times.\n",nameAndPass);
			printf("\n\n=========================================================================\n\n\n");
				mainMenu();
				return THREE_ATTEMPS;
			}
			else
				break;
		}
		else if(i=='$'){
			free(newPass);
			newPass=NULL;
			free(newAccountAndPass);
			newAccountAndPass=NULL;
			exitFunc();
		}
		else if(i=='#'){
			mainMenu();
			return ;
		}
		else{
			printf("Invalid Choice, Try Again\n");
		}
	}
}

void printLoginWrongPassMenu()
{
	printf("1.Re-enter password\n");
	printf("2.If you forgot your password, press '!'\n");
	printf("3.To go back to the first screen enter '#'\n");
	printf("4.To exit the app please enter '$'.\n");
}

char * getEncryptedPass(char *pass,char *randNum)
{
	UINT i,andRes,randRes,finalRes;
	int j;
	char * output;
	char *encryptedPassword=NULL;
	char **passArr;
	char *tmpPass=NULL;
	if(strlen(pass)==8){
		passArr = (char **)malloc(sizeof(char *) *ASCII_LENGTH);
//		randNum=(char *)malloc(sizeof(char)*WORD);
		for(j=0;j<PASS_LENGTH;j++)
			passArr[j]=NULL;
		tmpPass=pass;
		//printf("pass is - %s, tmpPass is - %s\n\n",pass,tmpPass);
		j=0;
		//create a binary array for all the characters in the password string
		while(*tmpPass){
			output = (char*)malloc(sizeof(char)*PASS_LENGTH);
			itoa(*tmpPass, output, 2);
			passArr[j]=output;
			j++;
			++tmpPass;
		}
		/*--------------------------------------------------------------------------*/
		// print the array of the binary of each character
		//printf("The Array Of passArr Is:\n");
		//for(j=0;j<8;j++)
		//	printf("%d - %s\n",j,passArr[j]);
	
		//printf("==============================================================\n");
		andRes=fromBinary(passArr[0]);
		for(i=1;i<7;i++){
			andRes&=fromBinary(passArr[i]);
		}

		/*--------------------------------------------------------------------------*/
		//free allocated memory
		for(j=0;j<PASS_LENGTH;j++){
			free(passArr[j]);
		}
		free(passArr);
		/*--------------------------------------------------------------------------*/
	
		/*-----------------------SelfCheck-------------------*/
		/*
		printf("After All : %x - %d\n",andRes,andRes);

		itoa(andRes,randNum,2);
		printf("After All : %s - %x\n",randNum,andRes);
		*/
		randRes=fromBinary(randNum);
		//printf("------  %s  --- %u ---\n",randNum,randRes);
		//printf("\n\nandRes is ----> %u\n\n",andRes);
		if(andRes%2==0)
			andRes<<=4;
		else
			andRes>>=6;
		finalRes=andRes^randRes;
		encryptedPassword=(char*)malloc(sizeof(char)*WORD);
		//printf("\n\n\n%u=%u^%u\n\n\n",finalRes,andRes,randRes);
		itoa(finalRes,encryptedPassword,2);
		//printf("After Action\n");
		//printf("%d ---- %s --- %d\n",finalRes,encryptedPassword,strlen(encryptedPassword));
	
		return encryptedPassword;
	}
	else
		return NULL;
}

void newPasswordEntry()
{
	char *newPassword=NULL;
	char *encryptNewPass=NULL;
	bool_t checkPassValidity;
	printf("\n\n=========================================================================\n\n\n");
	printf("hello Dear %s ! Please choose a new password\n",loginAccount->name);
	printf("\nInput : ");
	newPassword=getString();
	checkPassValidity = checkPasswordValidity(newPassword);
	while(!checkPassValidity){
		printf("\n\nDear %s, your password must be 8 characters long, and contain at least each of the following: A digit, a lower case letter and an upper case letter.Please try again.\n",loginAccount->name);
		printf("\nInput : ");
		free(newPassword);
		newPassword = NULL;
		newPassword = getString();
		checkPassValidity = checkPasswordValidity(newPassword);
	}
	encryptNewPass=getEncryptedPass(newPassword,loginAccount->randNum);
	free(loginAccount->password);
	loginAccount->password=(char*)malloc(strlen(encryptNewPass));
	strcpy(loginAccount->password,encryptNewPass);
	printf("Password Was Successfully Updated !\n\n");

}