#ifndef CREATE_NEW_USER_H_
#define CREATE_NEW_USER_H_

// defines
#define SIZE_OF_PASS 20

// functions declarations
void createNewAccount(void);
bool_t checkPasswordValidity(char *pass);
bool_t checkExistingAccount(char *accountName);
bool_t checkAccountNameValidity(char *accountName);
bool_t checkSecureAnsValidity(char *secureAns);
UINT getRand();
char *getRandomNumber();
UINT fromBinary(char *s);
char *getEncryptedPassword(char *pass,char *randNum);

char * getPassword();

#endif // CREATE_NEW_USER_H_
