#ifndef ACCOUNT_LINK_LIST_H_
#define ACCOUNT_LINK_LIST_H_

void fullFillAccountList(char* filename);
void addOneAccountToList(char *name,char *pass,char *randNum,char *secureAns);
void printAccountList();
void writeAccountsToFile();

void fullFillProfiles(char* filename);
void addOneAccountToProfiles(char *name,char *status,char *friends,profile *pending);
void writeProfilesToFile();
void printfProfiles();


#endif //ACCOUNT_LINK_LIST_H_