#ifndef DEFINITIONS_H_
#define DEFINITIONS_H_

// typedef
typedef void (*pfunc)(void);

typedef unsigned short int USHORT;
typedef enum boolean {FALSE=0,TRUE} bool_t;
typedef enum login {AACOUNT_NOT_EXIST=0,WRONG_PASS,RIGHT_PASS,BAD_INPUT_SYNTAX,PASS_LENGTH_ERROR} login_t;
typedef unsigned int UINT;

typedef struct account {
	char *name;
	char *password;
	char *randNum;
	char *securityAns;
	struct account *next;
}account_t;

typedef struct profileStruct{
	char *userName;
	char *status;
	char *friends;
	struct profileStruct *requestHead;
	struct profileStruct *next;
}profile;



// defines
#define BUFFER_SIZE 120
#define PROFILE_BUFF 512
#define SIZE 512
#define PASS_LENGTH 8
#define ASCII_LENGTH 8
#define WORD 32

#endif // DEFINITIONS_H_