﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <time.h>
#include "definitions.h"
#include "createNewUser.h"
#include "helpFuncs.h"


extern account_t *head;
extern void addOneAccountToList(char *name,char *pass,char *randNum,char *secureAns);
extern void addOneAccountToProfiles(char *name,char *status,char *friends,profile *pending);
extern void writeProfilesToFile();


void createNewAccount(void)
{
	bool_t checkIfExist,checkNameValidity,checkPassValidity,checkSecureValidity;
	bool_t twoPassCorrect=FALSE;
	char *accountName=NULL;
	char *accountPass=NULL;
	char *secAccountPass=NULL;
	char *encryptedPass=NULL;
	char *randNum=NULL;
	char *secureAns=NULL;
	printf("Hello dear guest, please choose a username\n");
	
	while(1){
		printf("\nInput : ");
		accountName=getString();
		checkIfExist = checkExistingAccount(accountName);
		//printf("checkIfExist - %d, For Account %s\n",checkIfExist,accountName);
		if(checkIfExist){
			printf("We are truly sorry - The username you chose is already used. Please choose again.\n");
			continue;
		}
		else {
		//	printf("The Name You Chose: %s\n",accountName);
			checkNameValidity=checkAccountNameValidity(accountName);
			//printf("checkNameValidity - %d\n",checkNameValidity);
			if(!checkNameValidity){
				printf("Dear guest, your username must contain only letters and at least one space. Please try again. \n");
				free(accountName);
				accountName=NULL;
				continue;
			}
				printf("Welcome %s! Please Choose a Password.",accountName);

			while (!twoPassCorrect){
				printf("\nInput : ");
				accountPass = getPassword();
				checkPassValidity = checkPasswordValidity(accountPass);
				while(!checkPassValidity){
					free(accountPass);
					accountPass=NULL;
					printf("\nDear %s, Please Choose A Password Contains At Least 1 Capital Letter & 1 Small Letter & A Number, its Length Must Be 8 !\n\n",accountName);
					printf("\nInput : ");
					accountPass = getPassword();
					checkPassValidity = checkPasswordValidity(accountPass);
				}
				printf("\nPlease Validate Your Password.");
				printf("\nInput : ");
				secAccountPass=getPassword();
				if(strcmp(accountPass,secAccountPass)==0)
					twoPassCorrect=TRUE;
				else
				{
					printf("\n\nWe are truly sorry - The passwords do not match. Please repeat password acquisition process.\n");
					twoPassCorrect=FALSE;
				}
			}

			randNum=getRandomNumber();
			encryptedPass=getEncryptedPassword(accountPass,randNum);
			//printf("The Random Num Is:- %s\n\n",randNum);
			printf("\nDear %s, Please Answer The Question Bellow:\n",accountName);
			printf("Question: When was your last underground guitar jam?");
			printf("\nInput : ");
			secureAns=getString();
			checkSecureValidity=checkSecureAnsValidity(secureAns);
			while(!checkSecureValidity){
				free(secureAns);
				secureAns=NULL;
				printf("\nDear %s, security answer can contain only letters, numbers and spaces. Please try again.\n",accountName);
				printf("\nInput : ");
				secureAns = getString();
				checkSecureValidity = checkSecureAnsValidity(secureAns);
			}
			addOneAccountToList(accountName,encryptedPass,randNum,secureAns);
			addOneAccountToProfiles(accountName,"","",NULL);
			
			free(accountName);
			free(encryptedPass);
			free(randNum);
			free(secureAns);
			accountName=NULL;
			encryptedPass=NULL;
			randNum=NULL;
			secureAns=NULL;
			break;
		}
	}

	printf("Successfully Added Account !\n");
		
	
}

bool_t checkPasswordValidity(char *pass)
{
	USHORT i=0,capitalCount=0,smallCount=0,numCount=0;
	while (*(pass+i)!='\0')
	{
		
		if (*(pass+i)>=65 && *(pass+i)<=90)
			capitalCount++;
		else if (*(pass+i)>=97 && *(pass+i)<=122)
			smallCount++;
		else if (*(pass+i)>=48 && *(pass+i)<=57)
			numCount++;
		i++;
	}
	//printf("i================> %d\n",i);
	if (capitalCount==0 || smallCount==0 || numCount==0 || i!=8)
		return FALSE;
	else
		return TRUE;
	
}


bool_t checkExistingAccount(char *accountName)
{
	account_t *tmp=head;
	while (tmp!=NULL)
	{
		if(!strcmp(tmp->name,accountName)){
			return TRUE;
		}
		tmp=tmp->next;
	}
	return FALSE;
}

bool_t checkAccountNameValidity(char *accountName)
{
	int i=0,count=0;
	while (*(accountName+i)!='\0')
	{
		if(!(*(accountName+i)>=65 && *(accountName+i)<=90)\
		 && !((*(accountName+i)>=97 && *(accountName+i)<=122)) &&\
		 (*(accountName+i)!=32))
			return FALSE;
		if(*(accountName+i)==' ')
		{
			count++;
		}
		i++;
	}
	if(count ==0)
	{
		return FALSE;
	}
	return TRUE;
}

char * getRandomNumber()
{
	char *randNum=NULL;
	UINT i;
	randNum=(char *)malloc(sizeof(char)*WORD);
	i=getRand();
	itoa(i,randNum,2);
	return randNum;	
}

UINT fromBinary(char *s) {
  return (UINT)strtol(s, NULL, 2);
}

UINT getRand()
{
	time_t t;
	srand((unsigned)time(&t));
	return rand();
}


bool_t checkSecureAnsValidity(char *secureAns){
	int i=0;
	while (*(secureAns+i)!='\0')
	{
		if(!(*(secureAns+i)>=65 && *(secureAns+i)<=90)\
		 && !((*(secureAns+i)>=97 && *(secureAns+i)<=122)) &&\
		 (*(secureAns+i)!=32) &&\
		 !(*(secureAns+i)>=48 && *(secureAns+i)<=57))
			return FALSE;
		i++;
	}
	return TRUE;
}

char *getEncryptedPassword(char *pass,char *randNum)
{
	UINT i,andRes,randRes,finalRes;
	int j;
	char * output;
	char **passArr;
	char *tmpPass=NULL;
	char *encryptedPass=NULL;
	encryptedPass=(char*)malloc(sizeof(char)*WORD);
	passArr = (char **)malloc(sizeof(char *) *ASCII_LENGTH);
	for(j=0;j<PASS_LENGTH;j++)
		passArr[j]=NULL;
	tmpPass=pass;
	//printf("pass is - %s, tmpPass is - %s\n\n",pass,tmpPass);
	j=0;
	//create a binary array for all the characters in the password string
	while(*tmpPass){
		output = (char*)malloc(sizeof(char)*PASS_LENGTH);
		itoa(*tmpPass, output, 2);
		passArr[j]=output;
		j++;
		++tmpPass;
	}
	/*--------------------------------------------------------------------------*/
	// print the array of the binary of each character
	/*
	printf("The Array Of passArr Is:\n");
	for(j=0;j<8;j++)
		printf("%d - %s\n",j,passArr[j]);
	
	printf("==============================================================\n");
	*/
	andRes=fromBinary(passArr[0]);
	for(i=1;i<7;i++){
		andRes&=fromBinary(passArr[i]);
	}
	randRes=fromBinary(randNum);
	/*--------------------------------------------------------------------------*/
	//free allocated memory
	for(j=0;j<PASS_LENGTH;j++){
		free(passArr[j]);
	}
	free(passArr);
	/*--------------------------------------------------------------------------*/
	
	/*-----------------------SelfCheck-------------------*/
	/*
	printf("After All : %x - %d\n",andRes,andRes);

	itoa(andRes,randNum,2);
	printf("After All : %s - %x\n",randNum,andRes);
	*/
	//printf("------  %s  ------\n",randNum);
	//printf("\n\nandRes is ----> %u\n\n",andRes);
	if(andRes%2==0)
		andRes<<=4;
	else
		andRes>>=6;
	finalRes=andRes^randRes;
	//printf("\n\n\n%u=%u^%u\n\n\n",finalRes,andRes,randRes);
	itoa(finalRes,encryptedPass,2);
	//printf("After Action\n");
	//printf("%d ---- %s --- %d\n",finalRes,encryptedPass,strlen(encryptedPass));
	
	free(pass);
	pass=NULL;
	return encryptedPass;
	
}

char * getPassword()
{
	char *pass = (char*)malloc(SIZE_OF_PASS);
	int i=0; 
	while( (pass[i]=getch()) != '\n' && pass[i]!='\r')
	{
		putchar('*');
		i++;
	}
	pass[i]='\0';
	return pass;

}