#ifndef HELP_FUNCS_H
#define HELP_FUNCS_H


#define GET_LOGIC_AND() 	randNum[7] & randNum[6] & randNum[5] & randNum[4]&\
							randNum[3] & randNum[2] & randNum[1] & randNum[0]

// functions declarations
char *getString();
void exitFunc(void);
int compareStrings(const void *pStr1, const void *pStr2);
int readLines(char ***pStrings);
int readLine(char **pStr,char *friends);
profile* findlinkinlinkedlist(profile* currentprofiles158,char* str);
profile* findrequest(profile* currentprofiles158,char* str);
profile* addonenodetorequestlist(char* username,char* status,char* friends,profile* current);
void freeeverything(profile* pro);
void freeallmemory(profile* pro);
#endif
