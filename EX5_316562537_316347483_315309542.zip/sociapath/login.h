#ifndef LOGIN_H_
#define LOGIN_H_

typedef enum loginTry {BACK_TO_MAIN,NEW_PASS,THREE_ATTEMPS} loginTry_t;

// functions declarations
void loginFunc(void);
void printMainMenu();
void mainMenu();
login_t loginValidation(char *accountNameAndPass);
loginTry_t wrongPassEntryMenu(char *nameAndPass);
void printLoginWrongPassMenu();
char * getEncryptedPass(char *pass,char *randNum);
void newPasswordEntry();
//globals
account_t *loginAccount;

#endif // LOGIN_H_
