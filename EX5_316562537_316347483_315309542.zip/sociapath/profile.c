#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "definitions.h"
#include "profile.h"
#include "login.h"
#include "helpFuncs.h"
#include "accountLinkList.h"

//typedef
typedef struct stringcase { char* string; void (*func)(void); } stringcases;

stringcases cases [] = { 
	{"profile", showMyProfile},
	{"status", updateMyStatus},
	{"printFriends",printFriends},
	{"checkRequests",checkRequests},
	{"printNetwork",printNetwork},
	{"#",updateAndBackToMainMenu},
	{"$",exitTheProgram}
};

//extern vars
extern account_t *loginAccount;
extern profile *currentProfiles;
extern int compareStrings(const void *pStr1, const void *pStr2);
int friendsCount=0;
int requestCount=0;



profile *myProfile=NULL;

void profileMenu()
{

	char *choice=NULL;
	initMyProfile();
	printf("\n\n=========================================================================\n\n\n");
	printStatuses();
	
	while(1){
		printf("\n=========================================================================\n\n");
		printf("What would you like to do next? Choose the option by entering the matched string\n\n");
		printProfileMenu();
		printf("\nInput : ");
		choice = getString();
		//switch case for string !
		myswitch(choice);
		if(strcmp(choice,"#")==0)
			return;

	}
}

void initMyProfile()
{
	profile *tmp=currentProfiles;
	char *friends,*requests;
	profile *tmpCount;
	char allFriends[500];
	requestCount=0;
	friendsCount=0;
	while(tmp!=NULL)
	{
		if(strcmp(tmp->userName,loginAccount->name)==0)
		{
			myProfile=tmp;
			strcpy(allFriends,myProfile->friends);
			friends=strtok(allFriends,"_$_\n");
			while(friends!=NULL)
			{
				friendsCount++;
				friends=strtok(NULL,"_$_");
			}
			tmpCount=myProfile;
			while(tmpCount->requestHead!=NULL)
			{
				strcpy(allFriends,tmpCount->requestHead->userName);
				requests=strtok(allFriends,"_$_\n");
				while(requests!=NULL)
				{
					requestCount++;
					requests=strtok(NULL,"_$_");
				}
				tmpCount=tmpCount->requestHead;
			}

			break;
		}
		tmp=tmp->next;
	}
	//printf("Friends Are : %d,    Requests Are : %d\n",friendsCount,requestCount);
}

void printStatuses()
{
	profile *tmp=NULL;
	char *friends;
	char allFriends[100];
	char *c;
	printf("\nHi %s And Welcome To Your Profile!\n",myProfile->userName);
	c = myProfile->status;
	if(strlen(myProfile->status) != 0)
	{
		printf("Your Status: %s\n\n",myProfile->status);
	}
	else
	{
		printf("You don't have a status yet.\n");
	}
	if(strlen(myProfile->friends) != 0)
	{
	printf("See what's on your friends' minds:\n");
	}
	else
	{
		printf("You don't have friends yet.\n");
	}
		strcpy(allFriends,myProfile->friends);

	friends=strtok(allFriends,"_$_\n");
	
	while(friends!=NULL)
	{
		tmp=currentProfiles;
		while(tmp!=NULL)
		{
			//printf("Friend - %s , userName: %s\n",friends,tmp->userName);
			if(strcmp(friends,tmp->userName)==0)
			{
				if(strlen(tmp->status)== 0)
				{
					printf("%s has no status.",friends);
				}
				else
				{
				printf("%s: %s\n",friends,tmp->status);
				}
			}
			tmp=tmp->next;
		}
		friends=strtok(NULL,"_$_");
	}
}

void printProfileMenu()
{
	printf("\"profile\" - show your profile.\n");
	printf("\"status\" - update your current status.\n");
	printf("\"checkStatus <friend_userName>\" - check a current status of a specific friend, whose userName you enter in the place of <friend_userName>\n");
	printf("\"checkRequests\" - check incoming friend requests\n");
	printf("\"printFriends\" - print the list of your friends (userNames)\n");
	printf("\"search\" - search SocioPath Network for a userName\n");
	printf("\"request <friend_userName>\" - send a friend request to the given username\n");
	printf("\"unfriend <friend_userName>\" - unfriend the entered friend\n");
	printf("\"printNetwork\" - print your social network\n");
	printf("\"#\" - logout and return to the first App screen\n");
	printf("\"$\" - exit the app.\n");
}


void showMyProfile()
{
	printStatuses();
}


void updateMyStatus()
{
	char *status;
	bool_t isValidStat=FALSE;
	char *newStatus=NULL;
	char yesOrNo;
	printf("Update your SocioPath status to share with your friends.\n");
	printf("input:");
	status=getString();
	isValidStat=isValidStatus(status);
	while(!isValidStat)
	{
		free(status);
		status=NULL;
		printf("Status Not Updated (Not Valid Input), Try Again\n");
		return;
	}
	if(strlen(status)>512)
	{
		printf("Warning: Your Status Is Too Long, would you like to take the first 512 letters ? otherwise enter a new status: (y/n)\n");
		if(yesOrNo=='y' || yesOrNo=='Y')
		{
			newStatus=(char *)malloc(SIZE+1);
			strncpy(newStatus,status,SIZE);
			free(status);
			status=NULL;
			myProfile->status=newStatus;
			printf("Status Updated Successfully\n");
			printStatuses();
			return;
		}
		else
		{
			free(status);
			status=NULL;
			printf("Please Enter A New Status:\n");
			printf("\nInput : ");
			status=getString();
			isValidStat=isValidStatus(status);
			if(!isValidStat)
			{
				free(status);
				status=NULL;
				printf("Status Not Updated (Not Valid Input), Try Again\n");
				return ;
			}
			myProfile->status=status;
			printf("Status Updated Successfully\n");
			printStatuses();
			return;
		}
	}
	myProfile->status=status;
	printf("Status Updated Successfully\n");
	printStatuses();
}



void myswitch( char* str ) 
{
	stringcases* pCase;
	char *first=NULL,*second=NULL;
	first=(char *)malloc(30);
	second=(char *)malloc(50);
	for( pCase = cases
		; pCase != cases + sizeof(cases)/sizeof(cases[0])
		; pCase++ )
	{
		if( 0 == strcmp( pCase->string, str ) ) {
			(*pCase->func)();
			return ;
		}
		else
		{
			sscanf(str,"%s %[^\n]s",first,second);
			//printf("%s --- %s\n",first, second);
			if(strcmp(first,"checkStatus")==0){
				free(first);
				first=NULL;
				checkStatus(second);
				free(second);
				second=NULL;
				free(str);
				return;
			}
			else if(strcmp(first,"search")==0){
				free(first);
				first=NULL;
				searchQuery(second);
				free(second);
				second=NULL;
				free(str);
				return ;
			}
			else if(strcmp(first,"request")==0){
				free(first);
				first=NULL;
				requestFriendship(second);
				free(second);
				second=NULL;
				free(str);
				return;
			}
			else if(strcmp(first,"unfriend")==0){
				free(first);
				first=NULL;
				unfriendAccount(second);
				free(second);
				second=NULL;
				free(str);
				return;
			}
		}
	}
	free(str);
	printf("\nDear %s, you have entered an illegal input. You are being transferred to the profile menu to choose again.\n ",myProfile->userName);
	
}


bool_t isValidStatus(char * status)
{
	int i=0;
	while (*(status+i)!='\0')
	{
		if(!(*(status+i)>=32 && *(status+i)<=126))
			return FALSE;
		i++;
	}
	return TRUE;
}

void checkStatus(char *str)
{
	profile *tmp=NULL;
	char *friends;
	char allFriends[50];
	strcpy(allFriends,myProfile->friends);
	friends=strtok(allFriends,"_$_\n");
	while(friends!=NULL)
	{
		if(strcmp(friends,str)==0){
			tmp=currentProfiles;
			while(tmp!=NULL)
			{
				//printf("Friend - %s , userName: %s\n",friends,tmp->userName);
				if(strcmp(friends,tmp->userName)==0)
				{
					if(strlen(tmp->status)!=0)
					printf("%s status is: %s\n",tmp->userName,tmp->status);
					else
						printf("\n%s doesn't have a status.\n",tmp->userName);
					return;
				}
				tmp=tmp->next;
			}
		}
		
		friends=strtok(NULL,"_$_");
	}
	printf("\nDear %s, you don't have a friend with the username: %s. You are being transferred to the profile menu to choose again. ",myProfile->userName,str);
}

void printFriends()
{
	char **allFriends;
	int i,n;
	n = readLines(&allFriends);
	qsort(allFriends, n, sizeof(char *), compareStrings);
	if(n>0)
	{
	printf("\nYour Friend List Is:\n");
	for (i = 0; i < n; i++)
            printf("%s\n", allFriends[i]);
	}
	else
	{
		printf("\nDear %s, you don't have any friends yet.\n",myProfile->userName);
	}
	//for (i = 0; i < n; i++)
		//free(allFriends[i]);

	free(allFriends);
}


void searchQuery(char *str)
{
	profile *tmp=currentProfiles;
	bool_t flag=FALSE;
	int j;
	char tmpArr[80];
	j=0;
	strlwr(str);
	while(tmp!=NULL)
	{
		strcpy(tmpArr,tmp->userName);
		strlwr(tmpArr);
		if(strstr(tmpArr,str))
		{
			if(j == 0)
			{
				printf("\nthe search of \"%s\" has found the following users within the SocioPath network:\n",str);
	            j=1;
			}
			else
			{
				j=1;
			}
			printf("* %s\n",tmp->userName);
			flag=TRUE;
		}
		tmp=tmp->next;
	}
	if(flag == FALSE)
	{
		printf("Dear %s, no results have been found.\n",myProfile->userName);
	}
}


void updateAndBackToMainMenu()
{
	writeProfilesToFile();
	return;
}

void exitTheProgram()
{

	exitFunc();
}

void checkRequests()
{
	
	char *request=NULL;
	char *pch=NULL;
	char flag=0;
	char *checkExistFriend=NULL;
	char *name;
	int j,j2;
	profile *mm;
	profile *tmp=currentProfiles;
	profile *reqTmp=myProfile->requestHead;
	profile *currP, *prevP;
	j=0;
	j2 = 0;
	while(1)
	{
		printf("\n\n=========================================================================\n\n\n");
		printf("Dear %s, you have %d friend requests\n",myProfile->userName,requestCount);
		if(requestCount!=0){
			printf("The pending friend requests are from the users:\n");
			reqTmp=myProfile->requestHead;
			while(reqTmp!=NULL){
				printf(" * %s\n",reqTmp->userName);
				reqTmp=reqTmp->requestHead;
			}
			printf("\nTo approve the request, enter \"approve::<username>\"\n");
			printf("To refuse and delete the request, enter \"refuse::<username>\"\n");
			printf("To back to the main selection menu, enter \"&\"\n");
			printf("\nInput : ");
			request = getString();
			pch=strtok(request,"::\n");
			if(strcmp(pch,"approve")==0)
			{
				pch=strtok(NULL,":\n");

				if(friendsCount==0){
					strcat(myProfile->friends,pch);
				
					mm =findlinkinlinkedlist(currentProfiles,pch);
				
					if(strlen(mm->friends) != 0)
					strcat(mm->friends,"_$_");
			
				strcat(mm->friends,myProfile->userName);
			
					friendsCount++;
				}
				else{
					checkExistFriend=strtok(myProfile->friends,"_$_");
					while(checkExistFriend!=NULL)
					{
						if(strcmp(checkExistFriend,pch)==0){
							printf("\n%s Is Already Your Friend !\n",pch);
							flag=1;
							break;
						}
						checkExistFriend=strtok(NULL,"_$_\n");
					}
					if(!flag)
					{
						strcat(myProfile->friends,"_$_");
						strcat(myProfile->friends,pch);
						mm =findlinkinlinkedlist(currentProfiles,pch);
						if(strlen(mm->friends)!=0)
						strcat(mm->friends,"_$_");
						strcat(mm->friends,myProfile->userName);
						friendsCount++;
					}
					else
						continue;
				}
				
				
			//	printf("Friends_%s\n",myProfile->friends);






				













				reqTmp=myProfile->requestHead;
				prevP=NULL;
				currP=myProfile->requestHead;
				for (currP = myProfile->requestHead;currP != NULL;prevP = currP, currP = currP->requestHead) 
				{
					if (strcmp(pch,currP->userName)==0) 
					{  /* Found it. */
						if (prevP == NULL) 
						{
							myProfile->requestHead = currP->requestHead;
						} 
					else 
							{
						prevP->requestHead = currP->requestHead;
					
						}		
						freeeverything(currP);



					//	myProfile->requestHead = prevP->requestHead;
						
						currP = NULL;
						requestCount--;
						printf("\nDear %s, %s has been added to your friends list.\n",myProfile->userName,pch);
						return;
					}
				}
				printf("\nDear %s, no such pending friend request exists. You are being transferred to the beginning of this stage in order to choose again.\n",myProfile->userName);
				continue;
			
			}
			else if(strcmp(pch,"refuse")==0)
			{
				pch=strtok(NULL,":\n");
				reqTmp=myProfile->requestHead;
				prevP=NULL;
				currP=myProfile->requestHead;
				for (currP = myProfile->requestHead;currP != NULL;prevP = currP, currP = currP->requestHead) 
				{
					if (strcmp(pch,currP->userName)==0) 
					{  /* Found it. */
						j=1;
						if (prevP == NULL) 
						{
							myProfile->requestHead = currP->requestHead;
						} 
						else 
						{
							prevP->requestHead = currP->requestHead;
						}		
						freeeverything(currP);
						requestCount--;
						printf("\nDear %s, %s request has been refused.\n",myProfile->userName,pch);
						return;
					}
				}
				if(j==0)
				{
					printf("\nDear %s, no such pending friend request exists. You are being transferred to the beginning of this stage in order to choose again.\n",myProfile->userName);
				}
				//printf("refuse :: %s\n",pch);
			}
			else if(strcmp(pch,"&")==0){
			//	printf("\nBack To Main !!\n");
				return;
			}
			else
			{
				printf("Dear %s, you have entered an illegal input. You are being transferred to the beginning of this stage in order to choose again.\n",myProfile->userName);
			}
		}
		else
			return;
	}
	
}

void requestFriendship(char *str)
{
	char *friends=NULL;
	char allFriends[50];
	profile *tmp=currentProfiles,*pendingProfiles=NULL;
	profile *tail;
	while(tmp!=NULL)
	{
		if(strcmp(myProfile->userName,str)==0)
		{
			printf("Dear %s, you can't be friend with yourself. You are being transferred to theprofile menu to choose again.\n",myProfile->userName);
			return;
		}
		if(findrequest(myProfile->requestHead,str) != NULL)
		{
			printf("Dear %s, %s has already sent you a friend request. Please check your \"checkRequests\" menu.\n",myProfile->userName,str);
			return;
		}
		pendingProfiles=tmp->requestHead;
		if(strcmp(tmp->userName,str)==0){
			while(pendingProfiles!=NULL){
				if(strcmp(pendingProfiles->userName,myProfile->userName)==0){
					printf("Dear %s, a friend request has already been sent to: %s. You are being transferred to the profile menu to choose again.\n",myProfile->userName,str);
					return;
				}
				pendingProfiles=pendingProfiles->requestHead;
			}
			
			strcpy(allFriends,tmp->friends);
			friends=strtok(allFriends,"_$_\n");
			while(friends!=NULL)
			{
				if(strcmp(friends,myProfile->userName)==0){
					printf("Dear %s, %s is already your friend. You are being transferred to the profile menu to choose again.\n",myProfile->userName,str);
					return;
				}
		
				friends=strtok(NULL,"_$_");
			}
			if(tmp->requestHead==NULL){
				tmp->requestHead=addonenodetorequestlist(myProfile->userName,myProfile->status,myProfile->friends,NULL);
				tmp->requestHead->requestHead=NULL;
			}
			else{
				while(tmp->requestHead->requestHead!=NULL)
				{
				//	tmp->requestHead=tmp->requestHead->requestHead;
						tmp=tmp->requestHead;
				}
				tmp->requestHead->requestHead=addonenodetorequestlist(myProfile->userName,myProfile->status,myProfile->friends,NULL);
				tmp->requestHead->requestHead->requestHead=NULL;
			}
			printf("Dear %s, a friend request has been sent to: %s.\n",myProfile->userName,str);
			return ;
		}
		tmp=tmp->next;
	}
	printf("Dear %s, SocioPath doesn't have a member by the username: %s. You are being transferred to the profile menu to choose again.\n",myProfile->userName,str);

}


void unfriendAccount(char* str)
{
	char *allFriends=NULL;
	char *pch=NULL;
	profile *mm;
	int c=0,len;
	int j2;
	char friends[512];
	strcpy(friends,"");
	j2=0;
	allFriends=strtok(myProfile->friends,"\n");
	pch=strtok(allFriends,"_\n");
	while(pch!=NULL)
	{
		if(strcmp(pch,str)!=0)
		{
			if(c==0)
			{
				strcpy(friends,pch);
			}
			else{
				strcat(friends,"_$_");
				strcat(friends,pch);
			}
			c++;
		}
		else
		{
			if(strcmp(pch,str)==0)
			j2=1;
		}
		pch=strtok(NULL,"_$_");
	}
	len=strlen(friends);
	friends[len+1]='\0';
	free(myProfile->friends);
	myProfile->friends=NULL;
	myProfile->friends=(char *)malloc(strlen(friends)+1);
	strcpy(myProfile->friends,friends);
	if(j2==0)
	{

		printf("Dear %s, you don't have any friend with the username: %s. You are being transferred to the profile menu to choose again.\n",myProfile->userName,str);
	}
	else
	{
		printf("Dear %s, %s in no longer your friend.\n",myProfile->userName,str);
		mm = findlinkinlinkedlist(currentProfiles,str);
		jjjjjjjjj(mm,myProfile->userName);
	}
}

void printNetwork()
{
	profile *tmp=NULL;
	char *friends=NULL,*infriends=NULL;
	char firstFriends[500]={0};
	char secondFriends[500]={0};
	int j =0;
	char allFriends[500]={0},allInnerFriends[500]={0};
	char inFriends[500]={0};
	char tmpAllFriends[500];
	printf("\n\n=========================================================================\n\n\n");
	printf("Dear %s, your social network is:\n",myProfile->userName);
	printf("You: %s\nYour Friends: ",myProfile->userName);
	strcpy(allFriends,myProfile->friends);
	friends=strtok(allFriends,"_$_\n");
	while(friends!=NULL)
	{
		strcat(firstFriends,friends);
		strcat(firstFriends,",");
		friends=strtok(NULL,"_$_\n");
	}
	firstFriends[(strlen(firstFriends)+1)]='\0';
	printf(" %s \n",firstFriends);
	strcpy(tmpAllFriends,firstFriends);
	friends=strtok(tmpAllFriends,",");
	while(friends!=NULL)
	{
		tmp=currentProfiles;
		while(tmp!=NULL)
		{
			if(strcmp(friends,tmp->userName)==0)
			{
				strcat(allInnerFriends,tmp->friends);
				strcat(allInnerFriends,"_$_");
			}
			tmp=tmp->next;
		}
		friends=strtok(NULL,",");
	}
	allInnerFriends[(strlen(allInnerFriends)+1)]='\n';
	printf("Friends of your Friends: ");
	strcpy(tmpAllFriends,allInnerFriends);
	friends=strtok(tmpAllFriends,"_$_");
	while(friends!=NULL){
		if(!(strstr(firstFriends,friends)) && !(strstr(secondFriends,friends))){
			if(strcmp(myProfile->userName,friends) != 0)
			{
				if(j == 0)
				{
						printf("%s",friends);
		j=1;
				}
				else
				{
						printf(", %s",friends);
		
				}
			}
		}
		friends=strtok(NULL,"_$_\n");
	}
	printf("\n");

}











































void jjjjjjjjj(profile* jamal,char* str)
{
	char *allFriends=NULL;
	char *pch=NULL;
	int c=0,len;
	char friends[512];
	strcpy(friends,"");
	allFriends=strtok(jamal->friends,"\n");
	pch=strtok(allFriends,"_\n");
	while(pch!=NULL)
	{
		if(strcmp(pch,str)!=0){
			if(c==0)
				strcpy(friends,pch);
			else{
				strcat(friends,"_$_");
				strcat(friends,pch);
			}
			c++;
		}
		pch=strtok(NULL,"_$_");
	}
	len=strlen(friends);
	friends[len+1]='\0';
//	free(jamal->friends);
	jamal->friends=NULL;
	jamal->friends=(char *)malloc(strlen(friends)+1);
	strcpy(jamal->friends,friends);
}
