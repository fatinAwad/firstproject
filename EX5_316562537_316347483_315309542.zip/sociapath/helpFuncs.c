#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "definitions.h"
#include "helpFuncs.h"
#include "accountLinkList.h"

extern account_t *head;
extern int friendsCount;
extern profile *myProfile;
extern profile *currentProfiles;

//get input string from the user - string size limited to SIZE chars and after user inpur resize to the actual string size (all done on the heap)
char* getString()
{
	char* pString;
	pString = (char*)malloc((SIZE*sizeof(char)));
	if (pString==NULL)
	{
		printf("error allocating memory for the queue\n");
	}
	scanf(" %[^\n]s",pString);
	pString = (char*)realloc(pString,((strlen(pString)+1)*sizeof(char)));
	if (pString==NULL)
	{
		printf("error allocating memory for the queue\n");
	}
	return pString;
}


void exitFunc(void)
{
	writeAccountsToFile();
	writeProfilesToFile();
	freeallmemory(currentProfiles);
	printf("Thank you for using 'SocioPath', we hope to see you again!\n Goodbye!\n");
	exit(0);
}



 
int readLine(char **pStr,char *friends) {
      char buf[256];
      int len;
	  sscanf(friends,"%[^\n]s",buf);
	  len = strlen(buf);
	  // remove new line character
	  if (buf[len - 1] == '\n')
		  buf[len - 1] = 0;
	  *pStr = (char *)calloc(len, sizeof(char));
	  strcpy(*pStr, buf);
	  return len;
		  
}
 
int readLines(char ***pStrings) {
      int i=0;
      char allFriends[120];
	  char *friends=NULL;
      *pStrings = (char **)calloc(friendsCount, sizeof(char *));
	  
	  strcpy(allFriends,myProfile->friends);
	  friends=strtok(allFriends,"_$_\n");
	  while(friends!=NULL)
	  {
		  readLine(&(*pStrings)[i],friends);
		  friends=strtok(NULL,"_$_");
		  i++;
	  }
              
      return i;
}
 
int compareStrings(const void *pStr1, const void *pStr2) {
      return strcmp(*(char **)pStr1, *(char **)pStr2);
}
profile* findlinkinlinkedlist(profile* currentprofiles158,char* str)
{
	profile *tmp;
	tmp = currentprofiles158;
	while(tmp != NULL)
	{
		if(strcmp(tmp->userName,str)==0)
		{
			return tmp;
		}
		tmp = tmp->next;
	}
	return NULL;
}
profile* findrequest(profile* currentprofiles158,char* str)
{
	profile *tmp;
	tmp = currentprofiles158;
	while(tmp != NULL)
	{
		if(strcmp(tmp->userName,str)==0)
		{
			return tmp;
		}
		tmp = tmp->requestHead;
	}
	return NULL;
}
profile* addonenodetorequestlist(char* username,char* status,char* friends,profile* current)
{
	profile * newnode;
	newnode = (profile*)malloc(sizeof(profile));
	if(newnode == NULL)
	{
		exit(1);
	}

	newnode->userName = (char*)malloc(strlen(username)+1);
	if(newnode->userName == NULL)
	{
		exit(1);
	}
	newnode->userName[0] = '\0';
					strcat(newnode->userName,username);

	newnode->status =(char*)malloc(strlen(status)+1);
	if(newnode->status == NULL)
	{
		exit(1);
	}
	newnode->status[0] = '\0';
	strcat(newnode->status,status);

	newnode->friends=(char*)malloc(strlen(friends)+1);
	if(newnode->friends == NULL)
	{
		exit(1);
	}
	newnode->friends[0] = '\0';
	strcat(newnode->friends,friends);
	newnode->requestHead = NULL;
	return newnode;
}
void freeeverything(profile* pro)
{
	if(pro->friends != NULL)
	free(pro->friends);
	if(pro->status != NULL)
	free(pro->status);
	if(pro->userName != NULL)
	free(pro->userName);
	free(pro);
	pro = NULL;
}
void freeallmemory(profile* pro)
{
	profile* tmp;
	profile* tmp2;
	profile* tmp3;
	
	tmp = pro;

	while(tmp != NULL)
	{	tmp2 = tmp->requestHead;
		while (tmp2 !=NULL)
		{
			tmp3 = tmp2;
		tmp2= tmp2->requestHead;
		freeeverything(tmp3);
	
		}
		tmp = tmp->next;
	}


	tmp = pro;
	while(tmp != NULL)
	{
		tmp2 = tmp;
		tmp = tmp ->next;
		freeeverything(tmp2);
	}
	
}