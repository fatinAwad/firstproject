#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "definitions.h"
#include "accountLinkList.h"

extern account_t *head;
extern profile *currentProfiles;
extern int jamalandmekhaanswer = 0;
extern int jamalandtofikanswer = 0;
extern char* valfilename;
extern char* profilename;


void fullFillAccountList(char* filename)
{
	char *pch=NULL;
	char name[50];
	char pass[32];
	char randNum[32];
	char secureAns[100];
	char line[100];
	size_t len;
	int i=0;
	FILE *fp=fopen(filename,"r");
	if ( fp == NULL ) {
		perror ( "Unable to open file" );
		exit ( EXIT_FAILURE );
	}
	fseek(fp, 0, SEEK_END);

    if (ftell(fp) == 0){
        return;
    }
	fseek(fp,0,SEEK_SET);
	
	while(fgets(line, BUFFER_SIZE, fp) != NULL) {
		len = strlen(line);
		// Note: under select circumstances, len will be 0.
		if (len > 0 && line[i-1] == '\n') 
			line[--len] = 0;

		// replace `&& input[0] != '\n'` with 
		if (len < 3) 
			continue; 
		
		//get a line from validation.txt file
		
		//printf("%s\n",line);
		// parsing the string
		/* walk through other pch */
		pch = strtok(line, "_$_");
		strcpy(name,pch);
		pch = strtok(NULL, "_$_");
		strcpy(pass,pch);
		pch = strtok(NULL, "_$_");
		strcpy(randNum,pch);
		pch = strtok(NULL, "_$_\n");
		strcpy(secureAns,pch);
		//printf("name: %s, password: %s, randNum: %s, securityAns: %s\n",name,pass,randNum, secureAns);
		addOneAccountToList(name,pass,randNum,secureAns);
		
	}
	fclose(fp);
			
}
	


void addOneAccountToList(char *name,char *pass,char *randNum,char *secureAns)
{
	account_t *newNode;
	jamalandmekhaanswer ++;

	newNode=(account_t*)malloc(sizeof(account_t));
	if(newNode == NULL)
	{
		printf("hehaha");
		exit(1);
	}
	newNode->name = (char *)malloc(strlen(name)+1);
	if(newNode == NULL)
	{
		printf("hehaha");
		exit(1);
	}
	strcpy(newNode->name,name);
	newNode->password = (char *)malloc(strlen(pass)+1);
	if(newNode == NULL)
	{
		printf("hehaha");
		exit(1);
	}
	strcpy(newNode->password,pass);
	newNode->randNum = (char *)malloc(strlen(randNum)+1);
	if(newNode == NULL)
	{
		printf("hehaha");
		exit(1);
	}
	strcpy(newNode->randNum,randNum);
	newNode->securityAns = (char *)malloc(strlen(secureAns)+1);
	if(newNode == NULL)
	{
		printf("hehaha");
		exit(1);
	}
	strcpy(newNode->securityAns,secureAns);
	newNode->next = head;
	head=newNode;
}

void printAccountList()
{
	account_t *tmp=head;
	printf("Printing All The Accounts\n\n");
	while (tmp!=NULL)
	{
		printf("name: %s, password: %s, randNum: %s, securityAns: %s\n",tmp->name,tmp->password\
			,tmp->randNum,tmp->securityAns);
		tmp=tmp->next;
	}
}

void writeAccountsToFile(){
	FILE *fp=fopen(valfilename,"w");
	int j,i;
	account_t *tmp=head,*ptr=NULL;
	j = jamalandmekhaanswer;

	
for( i = 0; i < j && tmp != NULL; i++)
{
	fprintf(fp,"%s_$_%s_$_%s_$_%s\n",tmp->name,tmp->password\
			,tmp->randNum,tmp->securityAns);
		ptr=tmp;
		tmp=tmp->next;
		free(ptr);
		ptr=NULL;
}	
	fclose(fp);
}


void fullFillProfiles(char* filename)
{
	char *pch=NULL;
	char *pending=NULL;
	char name[50];
	profile *tail;
	char status[PROFILE_BUFF];
	char friends[PROFILE_BUFF];
//	char pendingRequests[PROFILE_BUFF];
	profile *pendingProfile;
	profile *newPendingProfile=NULL;
	char line[PROFILE_BUFF];
	char tmp[50];
	int i=0;
	size_t len;
	int count=0;
	FILE *fp=fopen(filename,"r");
	if ( fp == NULL ) {
		perror ( "Unable to open file" );
		exit ( EXIT_FAILURE );
	}
	fseek(fp, 0, SEEK_END);

    if (ftell(fp) == 0){
        return ;
    }
	fseek(fp,0,SEEK_SET);

	while(fgets(line, PROFILE_BUFF, fp) != NULL) {
		
		//printf("----------------------------------------\n");
		len = strlen(line);
		//printf("%d\n",len);
		// Note: under select circumstances, len will be 0.
		if (len > 0 && line[i-1] == '\n') 
			line[--len] = 0;

		// replace `&& input[0] != '\n'` with 
		if (len < 3){
			count=0;
			continue;
		} 
		pch = strtok(line, "_");
		pch = strtok(NULL,"\n");
		switch(count)
		{
			case 0:
					strcpy(name,pch);
					//printf("name: %s\n",name);
					break;
			case 1:
					strcpy(status,(pch)?(pch):(""));
					//printf("Status: %s\n",status);
					break;
			case 2:
					strcpy(friends,(pch)?(pch):(""));
					//printf("Friends: %s\n",friends);
					break;
			case 3:
					strcpy(tmp,(pch)?(pch):(""));
					//printf("Pending: %s\n",tmp);
					pending=strtok(tmp,"_$_");
					pendingProfile=NULL;
					while(pending!=NULL)
					{
						
						if(pendingProfile==NULL)
						{
							pendingProfile=(profile*)malloc(sizeof(profile));
							if(pendingProfile == NULL)
							{
								exit(1);
							}
							
							pendingProfile->userName=(char*)malloc(strlen(pending)+1);
							pendingProfile->status=(char*)malloc(1);
							pendingProfile->friends=(char*)malloc(1);
							if(pendingProfile->userName == NULL  || pendingProfile->status==NULL || pendingProfile->friends == NULL)
							{
								exit(1);
							}
							strcpy(pendingProfile->userName,pending);
							pendingProfile->requestHead=NULL;
							tail=pendingProfile;








						}
						else
						{
							newPendingProfile=(profile*)malloc(sizeof(profile));
							if(newPendingProfile == NULL)
							{
								exit(1);
							}
							newPendingProfile->userName=(char*)malloc(strlen(pending)+1);
							newPendingProfile->status=(char*)malloc(1);
							newPendingProfile->friends=(char*)malloc(1);
							if(newPendingProfile->friends == NULL || newPendingProfile->status == NULL || newPendingProfile->userName == NULL )
							{
								exit(1);
							}
							newPendingProfile->requestHead=NULL;
							strcpy(newPendingProfile->userName,pending);
							tail->requestHead=newPendingProfile;
							tail=newPendingProfile;
							//newPendingProfile->requestHead=pendingProfile;
							//pendingProfile=newPendingProfile;
						}
						pending=strtok(NULL,"_$_\n");
					}					
					
		}
		count++;
		if(count==4){
			//printf("Name: %s\nStatus: %s\nFriends: %s\n",name,status,friends);
			addOneAccountToProfiles(name,status,friends,pendingProfile);
			count=0;
		}
		
		
	}
	fclose(fp);
	
}

void printfProfiles()
{
	profile *tmp=currentProfiles;
	profile *pendingReq;
	printf("Printing All The Profiles\n\n");
	while (tmp!=NULL)
	{
		pendingReq=tmp->requestHead;
		printf("UserName: %s\nStatus: %s\nFriends: %s\nPending: ",tmp->userName,tmp->status\
			,tmp->friends);
		while(pendingReq!=NULL)
		{
			printf("%s,",pendingReq->userName);
			pendingReq=pendingReq->requestHead;
		}
		printf("\n=================================\n");
		tmp=tmp->next;
	}
}

void addOneAccountToProfiles(char *name,char *status,char *friends,profile *pending)
{
	profile *newNode;
	jamalandtofikanswer++;
	
	newNode=(profile*)malloc(sizeof(profile));
	newNode->userName = (char *)malloc(strlen(name)+1);
	strcpy(newNode->userName,name);
	newNode->status = (char *)malloc(strlen(status)+1);
	strcpy(newNode->status,status);
	newNode->friends = (char *)malloc(strlen(friends)+1);
	strcpy(newNode->friends,friends);
	newNode->requestHead=pending;
	newNode->next=currentProfiles;
	currentProfiles=newNode;
}

void writeProfilesToFile()
{
	int i,j;
	FILE *fp=fopen(profilename,"w");
	profile *tmp=currentProfiles;
	int reqFriendCount;
	profile *pendingReq;
	j=jamalandtofikanswer;
	for(i=0; i < j && tmp != NULL; i++)
{		reqFriendCount=0;
		pendingReq=tmp->requestHead;
		fprintf(fp,"UserName_%s\nStatus_%s\nFriends_%s\nPending_",tmp->userName,tmp->status\
			,tmp->friends);
		while(pendingReq!=NULL)
		{
			if(reqFriendCount==0)
				fprintf(fp,"%s",pendingReq->userName);
			else
				fprintf(fp,"_$_%s",pendingReq->userName);
			reqFriendCount++;
			pendingReq=pendingReq->requestHead;
		}
		fprintf(fp,"\n\n");
		tmp=tmp->next;
}
	fclose(fp);
	
}