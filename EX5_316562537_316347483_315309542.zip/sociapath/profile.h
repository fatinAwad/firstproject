#ifndef PROFILE_H
#define PROFILE_H



void profileMenu();
void initMyProfile();
void printStatuses();
void printProfileMenu();

// function for string switch case !
void myswitch( char* str);

//Menu Functions
void showMyProfile();
void updateMyStatus();
void checkStatus(char *str);
void searchQuery(char *str);
void updateAndBackToMainMenu();
void checkRequests();
void requestFriendship(char *str);
void unfriendAccount(char* str);
void printNetwork();
void exitTheProgram();
void printFriends();
void jjjjjjjjj(profile* jamal,char* str);

// validity funcs
bool_t isValidStatus(char * status);




#endif