#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "definitions.h"
#include "login.h"
#include "createNewUser.h"
#include "helpFuncs.h"
#include "accountLinkList.h"


account_t *head=NULL;
profile *currentProfiles=NULL;
extern char* valfilename =0;
extern char* profilename =0;


int main(int argc,char* argv[])
{	
	valfilename = argv[1];
	profilename = argv[2];
	fullFillAccountList(argv[1]);
	fullFillProfiles(argv[2]);
	//printfProfiles();
	//printAccountList();

	printf("\nHello dear Guest and welcome to \'socioPath\' - Soicialize in an alternative path\'!\nWhat would you like to do next ?");
	mainMenu();
	return 0;
}

void printMainMenu()
{
	printf("\n1-Login\n");
	printf("2-Create a new account\n");
	printf("3-Exit the App\n");
}

void mainMenu()
{
	char* c;
	int i;
	pfunc fptr[3]={loginFunc,createNewAccount,exitFunc};
	while (1)
	{
		printMainMenu();
		printf("\nInput : ");
	
		c = getString();
		if(strlen(c) != 1)
		{
			printf("\nInvalid input. Dear guest, please enter '1', '2' or '3'.\n\nInput: ");
			continue;
		}
		else
		{
			i = *c-'0';
		}
		printf("\n\n=========================================================================\n\n\n");
		if (i>=1 && i<=3){
			fptr[i-1]();
		}
		else
			printf("\nInvalid input. Dear guest, please enter '1', '2' or '3'.\n\nInput: ");
		free(c);
	}
}


