#include "Ex2_q2_316562537.h"

#define ARRAY 10
int length (int num)
{
	if( num == 0)
		return 0;
	return 1+ length(num/10);
}

int fillArray (int arr[])
{
	int i,a=0,d=0;
	printf("Please enter %d numbers",SIZEARRAY);
	for(i=0;i< SIZEARRAY; i++)
	{
		scanf("%d",&arr[i]);
		if(a < length(arr[i]))
		{
			a = length(arr[i]);
		}
	}
	return a;
}

int getDigit (int num, int d)
{
	int f;
	f = num / pow(10.0 ,d-1);
		return f%10;
}

int mostCommonDigit (int arr[], int d)
{
	int arr2[ARRAY] = {0},w=0,max = 0;
	int i;
	for(i = 0; i <SIZEARRAY; i ++)
	{
		arr2[getDigit(arr[i],d)]++;
	}
	for (i = 0; i < 10; i++)
	{

		if(arr2[i] > max)
		{
			max = arr2[i];
			w = i;
		}
	}
	return w;
}

int main()
{
	int i ,d,w=0;
	int arr[SIZEARRAY]={0};
	d=fillArray(arr);
	for (i=d; i > 0; i--)
	{
		w = w *10;
		w= w+ mostCommonDigit(arr,i);
	}
	printf("The number is: %d\n",w);
	return 0;
}
