#include <stdio.h>

int isCoprime (int a, int b);
int eulerFunctionRecHelp (int num, int i);
int eulerFunctionRec (int num);
int smallestPrimeFactor (int num);
int eulerFunction (int num);