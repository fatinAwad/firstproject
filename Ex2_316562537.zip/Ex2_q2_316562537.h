#include <stdio.h>
#include <math.h>
#define SIZEARRAY 15

int length (int num);
int fillArray (int arr[]);
int getDigit (int num, int d);
int mostCommonDigit (int arr[], int d);
