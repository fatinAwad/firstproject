#include "Ex2_q1_316562537.h"
int isCoprime (int a, int b)
{
		if (a==0)
	{
		if (b!=1)
		{
			return 0;
		}
		return 1;
	}
	if (b==0)
	{
		if (a!=1)
			return 0;
		return 1;

	}
	return isCoprime (b, a%b);


}

int eulerFunctionRecHelp (int num, int i)
{
	if(i == 1)
	{
		return 1;
	}
	return  eulerFunctionRecHelp(num,i-1) + isCoprime(num,i);
}

int eulerFunctionRec (int num)
{
	return eulerFunctionRecHelp(num,num);
}

int smallestPrimeFactor (int num)
{
	int a, i;
	a=  eulerFunctionRec(num);
	if(a == num-1)
	{
		return num;
	}
	else
	{
		for(i=2; i < num; i ++)
		{
			if (num % i == 0 && i-1 == eulerFunctionRec(i))
			{
				return i;
			}
		}
	}
}

int eulerFunction (int num)
{
	 double a = num;
	 int i;
	 if(num-1 == eulerFunctionRec(num) )
	 {
		 a = a * (1 - 1/num);
		 i=a;
		 return i;
	 }
	 for ( i =2 ; i < num; i++)
	 {
		 if(i-1 == eulerFunctionRec(i) && num % i ==0)
	 {
		 a = a * (1 - 1.0/i);
	 }
	 
	 }
	 i=a;
	 return i;
}

int main()
{
	int a,b;
 printf("please enter a number:\n");
 scanf("%d",&a);
 if(a > 1000)
 {
	b = eulerFunction(a);
	printf("The Euler Function (method 2) is: phi(%d) = %d\n",a,b);
 }
 else
 {
	 b = eulerFunctionRec(a);
	 printf("The Euler Function (method 1) is: phi(%d) = %d\n",a,b);
 }
 return 0;
}