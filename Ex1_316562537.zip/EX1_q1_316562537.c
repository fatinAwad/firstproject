#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
int main()
{
	int x, i = 0;

	do
	{

		printf("please enter a number\n");
		scanf("%d", &x);
		if (x % 2 == 1)
			break;
		printf("Input error: the number must be odd\n");
		i++;



	} while (i < 3);
	if (x % 2 == 0)

		printf("Input failed 3 times, exiting\n");
	else
	{
		int p1 = 0, p2 = (x - 1) / 2, p3 = x - 1, i;
		while (p1 <= p3)
		{
			if (p1 == p2 && p2 == p3)
			{
				for (i = 0; i < x; i++)
				{
					printf("*");
				}
				printf("\n");
			}
			else
			{
				for (i = 0; i < x; i++)
				{
					if (i == p1)
						printf("*");
					else if (i == p2)
						printf("*");
					else if (i == p3)
						printf("*");
					else printf(" ");
				}
				printf("\n");

			}
			p1++;
			p3--;
		}
		p1 = (x - 1) / 2 - 1, p2 = (x - 1) / 2, p3 = (x - 1) / 2 + 1, i;
		while (p1 >= 0)
		{
			if (p1 == p2 && p2 == p3)
			{
				for (i = 0; i < x; i++)
				{
					printf("*");
				}
				printf("\n");
			}
			else
			{
				for (i = 0; i < x; i++)
				{
					if (i == p1)
						printf("*");
					else if (i == p2)
						printf("*");
					else if (i == p3)
						printf("*");
					else printf(" ");
				}
				printf("\n");
			}
			p1--;
			p3++;
		}



	}
	return 0;
}