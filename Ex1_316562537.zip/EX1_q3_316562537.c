#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{

	int option = 0, key = 0, i = 0, m = 0, f = 0;


	printf("Options:\n");
	printf("1.Encryption\n");
	printf("2.Decryption\n");

	printf("Please specify the command:\n");
	scanf("%d", &option);
	if ((option != 1) && (option != 2))
	{

		printf("Error: unknown command\n");
	}
	if (option == 1)
	{
		{
			printf("enter a string: \n");
			key = getchar();
			key = getchar();

			m = getchar();

			printf("Encryption is:");
			if ((key<97) || (key>122))
			{
				printf("\nError:input must be a letter between a-z");
				f = 1;
			}
			if (f == 0)
			{
				while (m != '\n')

				{
					if ((m<97) || (m>122))
					{
						printf("\nError:input must be a letter between a-z");
						break;
					}
					i = m;
					m = m + key - 96;
					key = i;

					
					if (m>122)
				{
					m = m - 122 + 96;

				}
					putchar(m);
					m = getchar();
				}
				printf("\n");
			}

		}
	}

	if (option == 2)
	{
		printf("enter a string: \n");
		key = getchar();
		key = getchar();

		printf("Decryption is:");
		if ((key<97) || (key>122))
		{
			printf("\nError:input must be a letter between a-z");
			f = 1;
		}
		m = getchar();

		if (f == 0)
		{
			while (m != '\n')

			{
				if ((m<97) || (m>122))
				{
					printf("\nError:input must be a letter between a-z");
					break;
				}
				m = m - (key - 96);
				key = m;
				if (m<97)
				{
					m = m - 96 + 122;

				}


				putchar(m);
				m = getchar();

			}
			printf("\n");
		}

	}

    return 0;
}