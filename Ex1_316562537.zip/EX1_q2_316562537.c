#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main()
{
	int x,y,newNum = 0;
	printf("Enter a number:\n"); 
	scanf("%d", &x);
	y=x;
	
	while (x > 0)
	{
		newNum = (newNum * 10) + (x % 10);
		x = x / 10;
	}

	if (newNum == y)
	{
		printf("%d is a pallindrome\n",newNum);
	}
	else
	{
		printf("%d isn't a pallindrome\n",newNum);
	}
	return 0;
}