#ifndef EX4_Q1_316562537_H
#define EX4_Q1_316562537_H

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct student{
int id;
int *grades;
double avg;
} Student;
void freeStudents (Student* studentArr, int numOfStudents);
void updateGrades (Student* studentArr, int numOfStudents, int factor, char factorOp);
Student getStudentFromString (char* str, double* weightsArr, int numOfGrades);
double calcAvgGrade (double* weightsArr, int* grades, int numOfGrades);
double* createWeightsArray (char* str, int numOfGrades);
Student* initStudentArray (int numOfStudents);
Student initStudent (int id, int* grades, double avg);
# endif
