
#include"Ex4_q1_316562537.h"
 int numOfStudentarg;
 Student* studentarr;
 int tav,counter =0,numofstudents;
 FILE *p1;
char *line;
char* Holder;
void printLog (Student* studentArr, int numOfStudents, FILE *fPtrWrite);
void readFromFile (Student* studentArr, int numOfStudents, FILE* fPtrRead);
#define size 50
