#include"Ex4_q1_316562537.h"
Student initStudent (int id, int* grades, double avg)
{
	Student x;
	x.avg=avg;
	x.grades=grades;
	x.id=id;
	return x;
}
Student* initStudentArray (int numOfStudents)
{
	Student *studentarray1=NULL;
	int i=0;
	studentarray1=(Student*) malloc( numOfStudents * sizeof(Student));
	if(studentarray1 == NULL)
	{
		printf("Memory allocation failed!\n");
		exit(1);
	}
	
	for(i;i<numOfStudents;i++)
	{
		studentarray1[i]=initStudent(0,NULL,0.0);

	}
	return studentarray1;
}
double* createWeightsArray (char* str, int numOfGrades)
{
	char *n;
	int i,key;
	double *m=NULL;
	m=(double*) malloc( numOfGrades * sizeof(double));
	if(m == NULL)
	{
		printf("Memory allocation failed!\n");
		exit(1);
	}
	
	for(i=0; i< numOfGrades;i++)
	{
	n=strstr(str,"%");
	*n='\0';
	n++;
	sscanf(str,"%d",&key);
	m[i] = key/100.0;
	while(*n == ' ')
	{
		n++;
	}
	str = n;
	}
	return m;
}
double calcAvgGrade (double* weightsArr, int* grades, int numOfGrades)
{
	double average=0;
	double* w,*weitsArrNewF;
	double* Holder;
	double aw=0,tempd,countw=0;
	int i,j,temp;
	weitsArrNewF = (double*)malloc(sizeof(double)*numOfGrades);
		if(weitsArrNewF == NULL)
	{
		printf("Memory allocation failed!\n");
		exit(1);
	}
	
	Holder = weitsArrNewF;
	w = weightsArr;
	for(i=0; i < numOfGrades; i++)
	{
		weitsArrNewF[i] = *w;
		aw = aw+ *w;
		w++;
	}
	if(aw == 1)
	{
		for (i=0; i <numOfGrades; i++)
			average = average + *(grades +i)**(weitsArrNewF +i);
	}
	if(aw < 1)
	{
			for (i=0; i <numOfGrades; i++)
				average = average + *(grades +i)**(weitsArrNewF +i);
	average = average + (1.0-aw)*100;
	}
	if(aw > 1)
	{
		for(i=0; i < numOfGrades; i++)
			for(j=0; j <numOfGrades; j++)
			{
				if((grades[j]) < (grades[i]))
				{
					temp =(grades[j]);
					(grades[j]) = (grades[i]);
					(grades[i]) = temp;
					tempd = (weitsArrNewF[j]);
					(weitsArrNewF[j]) = (weitsArrNewF[i]);
					(weitsArrNewF[i]) = tempd;
					
				}
			}
				for (i=0; i <numOfGrades; i++)
					if(countw + *(weitsArrNewF +i) <= 1)
						{
							average = average + *(grades +i)*(*(weitsArrNewF +i));
					countw = countw + *(weitsArrNewF +i);
					}
					else
					{
						if(countw == 1)
							break;
								average = average + *(grades +i)*(1-countw);
								break;
					
					}
	
	}
	free(Holder);
	return average;
}
Student getStudentFromString (char* str, double* weightsArr, int numOfGrades)
{
	char* temp;
 int *grades1,*grades2;
 int i,j;
 Student ST ;
 char**pt1,**pt2;
 double avr;
 grades1=(int*)malloc((numOfGrades)*sizeof(int));
 if(grades1 == NULL)
{
	printf("Memory allocation failed!\n");
	exit(1);
}
	
 grades2=grades1;
 pt1=(char**) malloc((numOfGrades+1)*sizeof(char*));
 if(pt1 == NULL)
{
	printf("Memory allocation failed!\n");
	exit(1);
}
	
 pt2=pt1;
 pt1[0]=str;
 for(i=1;i<numOfGrades+1;i++)
 {
	
 	 pt1[i]=strstr(pt1[i-1]," ");
     *pt1[i]='\0';
	 pt1[i]++;
 }
 for(i=0;i<numOfGrades;i++)
 {
	 sscanf(pt1[i+1],"%d",&grades1[i]);
 }
 temp = pt1[0];
 sscanf(temp,"%d",&j);
 avr=calcAvgGrade(weightsArr,grades1,numOfGrades);
 ST=initStudent(j,grades1,avr);
	 free(pt1);
 
 return ST;
}
void updateGrades (Student* studentArr, int numOfStudents, int factor, char factorOp)
{
	
	int i=0;

	double factor1=0.0,a=0;
	if(factorOp=='+')
	{
		for(i=0;i<numOfStudents;i++)
		{
			studentArr[i].avg+=factor;
			if(studentArr[i].avg>100)
			{
				studentArr[i].avg=100;
			}
			
			if(studentArr[i].avg-(int)studentArr[i].avg-0.5<0)
			{
				studentArr[i].avg=(int)studentArr[i].avg;
			}
			else
			{
				studentArr[i].avg=(int)studentArr[i].avg +1;
			}
							


		}
	}
	
	if(factorOp=='%')
	{
		a=(factor+100);
		factor1=a/100;
		for(i=0;i<numOfStudents;i++)
		{
			studentArr[i].avg*=factor1;
			if(studentArr[i].avg>100)
			{
				studentArr[i].avg=100;
			}
			if(studentArr[i].avg-(int)studentArr[i].avg-0.5<0)
			{
				studentArr[i].avg=((int)studentArr[i].avg);
			}
			else
			{
				studentArr[i].avg=(int)studentArr[i].avg +1;
			}
					
		}
	}
}
void freeStudents (Student* studentArr, int numOfStudents)
{
	int i=0;
	for(i=0;i<numOfStudents;i++)
	{
		free(studentArr[i].grades);
	}
	free(studentArr);

}
