#include"Ex4_q2_316562537.h"
void readFromFile (Student* studentArr, int numOfStudents, FILE* fPtrRead)
{
	int numofgrades,i=0,factor=0;
	double *weights;
	char line[size],*ptr,*ptr1,factorOp;
	fgets(line,size,fPtrRead);
	ptr=strstr(line,":");
	ptr++;
	sscanf(ptr,"%d",&numofgrades);
	
	fgets(line,size,fPtrRead);
		weights=createWeightsArray(line,numofgrades);
	
	for(i=0;i<numOfStudents;i++)
	{
		fgets(line,size,fPtrRead);
		studentArr[i]=getStudentFromString (line, weights,numofgrades);
	}
	if(!feof(fPtrRead))
	{
		fgets(line,size,fPtrRead);
		ptr=strstr(line,":");
	   ptr++;
		ptr1=ptr;
		if(strstr(line,"%")!=NULL)
		{
			ptr1=strstr(line,"%");
			factorOp=*ptr1;
			*ptr1='\0';
			sscanf(ptr,"%d",&factor);
			updateGrades ( studentArr,numOfStudents,factor ,factorOp);
			
		}
		if(strstr(line,"+")!=NULL)
		{
			ptr1=strstr(line,"+");
			factorOp=*ptr1;
			*ptr1='\0';
			sscanf(ptr,"%d",&factor);
			updateGrades ( studentArr,numOfStudents,factor ,factorOp);
			

	
		}
	
		for(i=0;i<numOfStudents;i++)
		{

			if(studentArr[i].avg-(int)studentArr[i].avg-0.5<0)
			{
				studentArr[i].avg=(int)studentArr[i].avg;
			}
			else
			{
				studentArr[i].avg=(int)studentArr[i].avg +1;
			}
		}
		free(weights);

	}

}
void printLog (Student* studentArr, int numOfStudents, FILE *fPtrWrite)
{
	int i=0,numf=0,idf=0,c=0,max=0,min=0,num=0;
	double avg=0;
	fprintf(fPtrWrite,"The final grades in the course:\n");
	for(i=0;i<numOfStudents;i++)
	{
	fprintf(fPtrWrite,"%d final grade is %g\n",studentArr[i].id,studentArr[i].avg);
	}
	for(i=0;i<numOfStudents;i++)
	{
		avg+=studentArr[i].avg;
	}
	avg=avg/numOfStudents;
	fprintf(fPtrWrite,"The average grade is %g\n",avg);
	for(i=0;i<numOfStudents;i++)
	{
		if(studentArr[i].avg<60)
		{

			numf++;
		}
	}
	if(num==0)
	{
		fprintf(fPtrWrite,"The number of failures is %d\n",numf);
	}
	else
	{
	fprintf(fPtrWrite,"The number of failures is %d. The students who have failed:\n",numf);
	for(i=0;i<numOfStudents;i++)
	{

		if(studentArr[i].avg<60)
		{
			if(c==numf-1)
			{
				idf=studentArr[i].id;
				fprintf(fPtrWrite,"%d\n",idf);
			}
			else
			{

			idf=studentArr[i].id;
			fprintf(fPtrWrite,"%d, ",idf);
			c++;
			}

		}
	}
	}
	max=studentArr[0].avg;
	for(i=1;i<numOfStudents;i++)
	{
		
		if(max<studentArr[i].avg)
		{
			max=studentArr[i].avg;
		}
	}
	fprintf(fPtrWrite,"The highest grade is %d\n",max);
		min=studentArr[0].avg;
	for(i=1;i<numOfStudents;i++)
	{
		
		if(min>studentArr[i].avg)
		{
			min=studentArr[i].avg;
		}
	}
	fprintf(fPtrWrite,"The lowest grade is %d\n",min);
}
int main(int argc, char* argv[])
{

 p1 = fopen(argv[1],"r");
 if(p1 == NULL)
 {
  printf("There was error using files\n");
  exit(1);

 }
 
  tav = getc(p1);
 line = (char*)malloc(size*sizeof(char));
  if(line == NULL)
 {
  printf("Memory allocation failed!\n");
  exit(1);
 }
 Holder = line;
 while(tav != '\n')
 {
  line[counter] = tav;
  counter++;
  tav = getc(p1);
 
 }
 line[counter] = '\0';
 while(*line < 48 || *line > 57)
 {
  line++;
 }
 sscanf(line,"%d",&numofstudents);
 sscanf(argv[3],"%d",&numOfStudentarg);
  if(numOfStudentarg != numofstudents)
 {
  fclose(p1);
  p1 = fopen(argv[2],"w");
 if(p1 == NULL)
 {
  printf("File did not open. Exit..\n");
  exit(1);
 }
 fprintf(p1,"The number of students is not compatible with the argument");
 fclose(p1);
 
  return 1;
 }
 free(Holder);
 studentarr = initStudentArray(numofstudents);
 
 readFromFile(studentarr,numofstudents,p1);
  fclose(p1);
 p1 = fopen(argv[2],"w");
 if(p1 == NULL)
 {
  printf("File did not open. Exit..\n");
  exit(1);
 }
 printLog(studentarr,numofstudents,p1);
 freeStudents(studentarr,numofstudents);
 fclose(p1);
 return 0;
 
}