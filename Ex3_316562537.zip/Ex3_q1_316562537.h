#include <stdio.h>
#include <string.h>
#define STORE_SIZE 50 
#define ITEM_NAME_LENGTH 50 
#define DEPARTMENT_NAME_LENGTH 20 
#define EXPIRATION_DATE_STRING_LENGTH 6 
#define SizeArray STORE_SIZE+ITEM_NAME_LENGTH+DEPARTMENT_NAME_LENGTH+EXPIRATION_DATE_STRING_LENGTH +150

typedef struct _item{ 
 char item_name[ITEM_NAME_LENGTH]; 
 char department[DEPARTMENT_NAME_LENGTH]; 
 char expiration_date[EXPIRATION_DATE_STRING_LENGTH]; 
 double price; 
int available; 
} Item;
int i = 0,j1=0,j,op,j2,f=0,k=0,cntp=0,chk=0;
double Balance=0,money=0;
double* Balancepoint = &Balance;
char date[6];
Item StoreMain[STORE_SIZE];
Item* Store[STORE_SIZE];
Item* findItem(char *name,Item* store[],int *itemcount);
Item* finddate(char *name,Item* store[],int *itemcount);
Item* findkind(char *name,Item*store[],int *itemcount);
Item* findprice(double pt1,Item* words[],int *pt2);
void deleteitem(Item *word[],Item*pt1,int* counter,int i2);
int get_number_of_possibilities(Item* inventory[], double money, int size);
void expirationdate(char * date,Item* word[],int* pt2,double* balance);
void updateavilable(Item*pt1,int j);
void returnitem(Item* words[],int *pt2,double * balance);
void availabledwindle(Item*pt1,int j);
void buyitem(Item* words[],int *pt2,double* balancepoint);
int sortnumber(double j,double k);
int sortwords(char *jword,char*kword);
void namesortarray(Item* arrayp[],int length);
void departsortarray(Item* arrayp[],int length);
void datesortarray(Item* arrayp[],int length);
void pricesortarray(Item* arrayp[],int length);
void availablesortarray(Item* arrayp[],int length);
int Stop(Item* pt1,Item* word[],int *pt,double *balance,int index );
void printsc(int i,Item* Store[]);
void datesortarray1(Item* arrayp[],int length);

