#include "Ex3_q1_316562537.h"

Item* findItem(char *name,Item* store[],int *itemcount)//a function that receives an item,number of items name and returns the address of the item if existed
{
	int i=0;
	for(i=0;i<*itemcount;i++)
	{
		if(memcmp(name,store[i]->item_name,strlen(store[i]->item_name))==0)
		{
			return store[i];
		}
	}
	return 0;

}
Item* finddate(char *name,Item* store[],int *itemcount)//a function that search for an item date and return the address of thiss item 
{
	int i=0;
	for(i=0;i<*itemcount;i++)
	{
		if(memcmp(name,store[i]->expiration_date,strlen(store[i]->expiration_date))==0)
		{
			return store[i];
		}
	}
	return 0;

}
Item* findkind(char *name,Item*store[],int *itemcount)//a function that search for an item kind and return the address of thiss item 
{
	int i=0;
	for(i=0;i<*itemcount;i++)
	{
		if(memcmp(name,store[i]->department,strlen(store[i]->department))==0)
		{
			return store[i];
		}
	}
	return 0;

}
Item* findprice(double pt1,Item* store[],int *itemcount)//a function that search for an item price and return the address of thiss item 
{
	int i=0;
	for(i=0;i<*itemcount;i++)
	{
		if(pt1 == store[i]->price)
		{
			return store[i];
		}
	}
	return 0;

}
 void deleteitem(Item *word[],Item*pt1,int* counter,int i2)//a function that searches for the desired item and delete it
{
		 int i=0,j;
	 Item *pt2=pt1;
	 i=*counter- i2;
	 for(j =0; j<i; j++)
	 {
		 pt1 = word[i2+j+1];
		 word[i2+j]=pt1;
	 }
	 word[i2+j] = pt2;
	 *counter = *counter - 1;
}
int get_number_of_possibilities(Item* inventory[], double money, int size)
{
	int i =0,counter=0;
	if(money < 0)
	{
		return 0;
	}
	if(money == 0)
	{
		return 1;
	}
	if(size == 0)
	{
		return 1;
	}

	for (i = 0 ; i < size; i ++)
		if(inventory[size-i-1]->available !=0)
			return get_number_of_possibilities(inventory,money-inventory[size-i-1]->price,size-1) + get_number_of_possibilities(inventory,money,size-1);
		else return get_number_of_possibilities(inventory,money,size-1);
	return 0;
}
void expirationdate(char * date,Item* word[],int* pt2,double* balance)//a function for dealing with the expiration date
{
	 int i;
	 Item* pt3;
	 for(i=0; i < *pt2; i++)
	 {
		 if(sortwords(date,word[i]->expiration_date)    ==0 )
			{
				
			  pt3 =	findItem(word[i]->item_name,word,pt2);

			  *balance = *balance - word[i]->available*word[i]->price;
			  deleteitem(word,word[i],pt2,i);
			
			  i--;
			}
	 }
}
void updateavilable(Item*pt1,int j)//when called it adds available
 {
	 int i;
	 i=pt1->available;
	 pt1->available = (i+j);
 }
void returnitem(Item* words[],int *pt2,double * balance)//return a desired item
{
	int i=0,key = 0;
	char string1[SizeArray];
	Item * pt5;
	key=getchar();
	key=getchar();
	while(key != '\n')
	{
	
		string1[i] = key;
		key = getchar();
		i++;
	}
	string1[i]= '\0';
	scanf("%d",&key);
	pt5 = findItem(string1,words,pt2);
	if(pt5 == 0)
	{
		printf("You did not purchase this %s in this store!\n\n\n",string1);
	}
	else
	{
	if(key == 1)
	{
		*balance = *balance -pt5->price;
		printf("One %s was successfully returned.\n\n\n",string1);
		
	}
	else
	{
			*balance = *balance - pt5->price*key;
		printf("%d %ss were successfully returned.\n\n\n",key,string1);
	
	}
	updateavilable(pt5,key);

	}
}
 void availabledwindle(Item*pt1,int j)//when calls this function it substract the available
 {
	 int i;
	 i=pt1->available;
	 pt1->available = (i-j);
 }
 void buyitem(Item* words[],int *pt2,double* balancepoint)
 {
	int i=0 ,key=0, counter=0;
	char string1[SizeArray] ;
	Item * pt5;
	key=getchar();
	key=getchar();
	while(key != '\n')
	{
		string1[i] = key;
		key = getchar();
		i++;
	}
	string1[i]= '\0';
	scanf("%d",&key);
	pt5 = findItem(string1,words,pt2);
	if(pt5 == 0)
	{
		printf("There are no %ss in our inventory.\n\n\n",string1);
	}
	else
	{
	if(pt5->available >= key)
	{
		availabledwindle(pt5,key);
		counter++;
	    if(key ==1)
	{
		*balancepoint = *balancepoint +   (pt5->price);
		printf("You purchased one %s successfully.\n\n\n",string1);
	}
		else
		{
		*balancepoint = *balancepoint +  key* (pt5->price);
	printf("You purchased %d %ss successfully.\n\n\n",key,string1);
		}
	
	}
	
	if(pt5->available < key && counter!=1)
	{
		if(pt5->available == 1)
		{

			printf("There was only one %s in our inventory, which you took.\n\n\n",string1);
			*balancepoint = *balancepoint + (pt5->available) * (pt5->price);
			availabledwindle(pt5,pt5->available);
		}
		else
		{

			printf("There were only %d %ss in our inventory, which you took.\n\n\n",pt5->available,string1);
			*balancepoint = *balancepoint + (pt5->available) * (pt5->price);

			availabledwindle(pt5,pt5->available);
		}
	}
	}
 }
int sortnumbers(double j,double k)
{

if(j > k)
			return 0;
		if(k > j)
			return 1;
		return 2;
		}
int sortwords(char *jword,char*kword)
{
	while(*jword != '\0' && *kword !='\0')
	{
		if(*jword > *kword)
			return 0;
		if(*kword > *jword)
			return 1;
		jword++;
		kword++;
	}
	if(*jword == '\0' && *kword =='\0')
	{
		return 2;
	}
	if(*jword == '\0')
	{ 
		return 0;
	}
if(*kword =='\0')
	{
		return 1;
	}

}
void namesortarray(Item* arrayp[],int length)
{
	int i =0, j=0;
	Item * Temp;
	Item* pointer1;
	Item* pointer2;
	for(i=0; i < length; i++)
		for(j=i; j<length; j++)
		{
			if(sortwords(arrayp[i]->item_name,arrayp[j]->item_name) ==0)
			{
				pointer1 = arrayp[i];
				pointer2=arrayp[j];
			
	Temp = arrayp[i];
	arrayp[i] = arrayp[j];
	arrayp[j] = Temp;
				
			}
		}
}
void departsortarray(Item* arrayp[],int length)
{
	int i =0, j=0;
	Item * Temp;
	Item* pointer1;
	Item* pointer2;
	for(i=0; i < length; i++)
		for(j=i; j<length; j++)
		{
			if(sortwords(arrayp[i]->department,arrayp[j]->department) ==0)
			{
				pointer1 = arrayp[i];
				pointer2=arrayp[j];
			
	Temp = arrayp[i];
	arrayp[i] = arrayp[j];
	arrayp[j] = Temp;
			
			}
		}
}
void datesortarray(Item* arrayp[],int length)
{
	int i =0, j=0;
	Item * Temp;
	Item* pointer1;
	Item* pointer2;
	for(i=0; i < length; i++)
		for(j=i; j<length; j++)
		{
			if(sortwords(arrayp[i]->expiration_date,arrayp[j]->expiration_date) ==0)
			{
				pointer1 = arrayp[i];
				pointer2=arrayp[j];
			
	Temp = arrayp[i];
	arrayp[i] = arrayp[j];
	arrayp[j] = Temp;
				//	changepointerinarray(arrayp[i],arrayp[j]);
			}
		}
}
void pricesortarray(Item* arrayp[],int length)
{
	int i =0, j=0;
	Item * Temp;
	Item* pointer1;
	Item* pointer2;
	for(i=0; i < length; i++)
		for(j=i; j<length; j++)
		{
			if(sortnumbers(arrayp[i]->price,arrayp[j]->price) ==0)
			{
				pointer1 = arrayp[i];
				pointer2=arrayp[j];
			
	Temp = arrayp[i];
	arrayp[i] = arrayp[j];
	arrayp[j] = Temp;
			
			}
		}
}
void availablesortarray(Item* arrayp[],int length)
{
	int i =0, j=0;
	Item * Temp;
	Item* pointer1;
	Item* pointer2;
	for(i=0; i < length; i++)
		for(j=i; j<length; j++)
		{
			if(sortnumbers(arrayp[i]->available,arrayp[j]->available) ==0)
			{
				pointer1 = arrayp[i];
				pointer2=arrayp[j];
			
	Temp = arrayp[i];
	arrayp[i] = arrayp[j];
	arrayp[j] = Temp;
				
			}
		}
}
int Stop(Item* pt1,Item* word[],int *pt,double *balance,int index )//a function that divides the input and puts the data to items store
{
	Item *pt6,*pt7,*pt8;
	int i=0,key = 0,available,namelength,departmentlength,datelength;
	char string1[SizeArray];
	char *words[6];
	double price2,Price;
	Item* ptr5;
	key=getchar();
	while(key != '\n')
	{
		string1[i] = key;
		key = getchar();
		i++;
	}
	string1[i]= '\0';
	words[0] = string1;
	if(memcmp(words[0],"stop",4)==0)
	{
		return 1;
	}
	words[1] = strstr(words[0],"_*_");
	*words[1]='\0';
	words[1]+=3;
	words[2] = strstr(words[1],"_*_");
	*words[2]='\0';
	words[2]+=3;
	
	words[3] = strstr(words[2],"_*_");
	*words[3]='\0';
	words[3]+=3;
	
	words[4] = strstr(words[3],"_*_");
	*words[4]='\0';
	words[4]+=3;

	i=0;
	 sscanf(words[3],"%lf",&Price);
	ptr5 = findItem(words[0],word,pt);
	pt6 = finddate(words[2],word,pt);
	pt7 = findkind(words[1],word,pt);
	pt8 = findprice((double)(Price),word,pt);
	if((ptr5==0) || (pt6==0) ||(pt7==0) ||(pt8==0)) 
	{
	namelength = strlen(words[0]) +1;
	departmentlength = strlen(words[1]) +1;
	datelength = strlen(words[2]) +1;
	memmove(pt1->item_name,words[0],namelength);
	memmove(pt1->department,words[1],departmentlength);
	memmove(pt1->expiration_date,words[2],datelength);
		 sscanf(words[3],"%lf",&Price);
		sscanf(words[4],"%d",&available);
	pt1->price= (double)(Price);
	pt1->available= (int)(available);
	*pt =*pt + 1;
	if(index == 1)
	*balance = *balance - pt1->available*pt1->price;
	return 0;
	}
	else
	{
	sscanf(words[4],"%d",&available);
	if(index == 1)
				*balance = *balance - available*ptr5->price;
	
		ptr5->available =ptr5->available + (int)available; 
return 0;
	}
	return 0;
}
void printsc(int i,Item* Store[])
{ int f=0;

for(f;f<i;f++)
{
	
	printf("%s_*_",Store[f]->item_name);
	printf("%s_*_",Store[f]->department);
	printf("%s_*_",Store[f]->expiration_date);
	
	printf("%g_*_",Store[f]->price);
	printf("%d\n",Store[f]->available);
}
	printf("\n\n\n\nPlease choose an operation for the automated system to do.\n");

printf("Choose 1 to order the computer to sort the inventory alphabetically by item names.\n");

printf("Choose 2 to order the computer to sort the inventory alphabetically by department names.\n");

printf("Choose 3 to order the computer to sort the inventory by the expiration dates.\n");

printf("Choose 4 to order the computer to sort the inventory by the price.\n");

printf("Choose 5 to order the computer to sort the inventory by the availability.\n");

printf("Choose 6 to order the computer to update the inventory after a customer finished shopping.\n");

printf("Choose 7 to order the computer to update the inventory after a customer returned an item.\n");

printf("Choose 8 to order the computer to update the inventory after a supplier sold the store an item.\n");

printf("Choose 9 to order the computer to update the inventory after throwing expired items.\n");

printf("Choose 10 to order the computer to produce a shopping tactic for a customer.\n");

printf("In order to turn off the computer and get the final output choose 0.\n\n");

printf("Do not forget to check the store's balance after each operation!\n\n");

}
void datesortarray1(Item* arrayp[],int length)
{
	int i =0, j=0;
	Item * Temp;
	Item* pointer1;
	Item* pointer2;
	for(i=0; i < length; i++)
		for(j=i; j<length; j++)
		{
			if(sortwords(arrayp[i]->expiration_date,arrayp[j]->expiration_date) ==1)
			{
				pointer1 = arrayp[i];
				pointer2=arrayp[j];
			
	Temp = arrayp[i];
	arrayp[i] = arrayp[j];
	arrayp[j] = Temp;
				//	changepointerinarray(arrayp[i],arrayp[j]);
			}
		}
}

int main ()
{	
printf("Welcome to Mr. Kashtan's store, dear new employee!\n");

printf("Enter up to %d items to our grocery store.\n", STORE_SIZE);

printf("The items should be entered in the format:\n");

printf("item name_*_department_*_expiration date in the format mm.dd_*_price in the format xx.yy_*_number of available items of that type\n\n");

printf("In order to enter less then %d items just enter the string \"stop\".\n\n", STORE_SIZE);
	for(i=0; i <STORE_SIZE; i++)
	{
		Store[i]=&StoreMain[i];
	}
	i=0;
while(i < STORE_SIZE && j1 == 0)
{
	j1 = Stop(Store[cntp],Store,&cntp,&Balance,0);
	
	
}



printf("\n\n\n\nPlease choose an operation for the automated system to do.\n");

printf("Choose 1 to order the computer to sort the inventory alphabetically by item names.\n");

printf("Choose 2 to order the computer to sort the inventory alphabetically by department names.\n");

printf("Choose 3 to order the computer to sort the inventory by the expiration dates.\n");

printf("Choose 4 to order the computer to sort the inventory by the price.\n");

printf("Choose 5 to order the computer to sort the inventory by the availability.\n");

printf("Choose 6 to order the computer to update the inventory after a customer finished shopping.\n");

printf("Choose 7 to order the computer to update the inventory after a customer returned an item.\n");

printf("Choose 8 to order the computer to update the inventory after a supplier sold the store an item.\n");

printf("Choose 9 to order the computer to update the inventory after throwing expired items.\n");

printf("Choose 10 to order the computer to produce a shopping tactic for a customer.\n");

printf("In order to turn off the computer and get the final output choose 0.\n\n");

printf("Do not forget to check the store's balance after each operation!\n\n");
scanf("%d",&op);

while(op!=0)
{
if(op==1)
{
	namesortarray(Store,cntp);

	printf("\nYou chose to sort the inventory by the names of the items.\n");
    printf("\n\nThere are %d items in the invertory.\n",cntp);
	printf("The items are:\n\n");
    printsc(cntp,Store);
	scanf("%d",&op);
}
if(op==2)
{
	departsortarray(Store,cntp);
	printf("\nYou chose to sort the inventory by departments.\n");
	printf("\n\nThere are %d items in the invertory.\n",cntp);
	printf("The items are:\n\n");
	 printsc(cntp,Store);
	scanf("%d",&op);
}
if(op==3)
{
	datesortarray(Store,cntp);
	printf("\nYou chose to sort the inventory by expiration date.\n\n\n");
		printf("There are %d items in the invertory.\n",cntp);
	printf("The items are:\n\n");
	 printsc(cntp,Store);
	scanf("%d",&op);
}
if(op==4)
{
	pricesortarray(Store,cntp);
	printf("\nYou chose to sort the inventory by price.\n\n\n");
		printf("There are %d items in the invertory.\n",cntp);
	printf("The items are:\n\n");
	 printsc(cntp,Store);
	scanf("%d",&op);
}
if(op==5)
{
	availablesortarray(Store,cntp);
	
	printf("\nYou chose to sort the inventory by available number of items of that type.\n\n\n");

	printf("There are %d items in the invertory.\n",cntp);
	printf("The items are:\n\n");
 printsc(cntp,Store);
	scanf("%d",&op);
}
if(op==6)
{
	printf("\nYou chose to buy an item from the inventory. Please tell us what you want to buy and how many.\n\n");
	buyitem(Store,&cntp,Balancepoint);
	printf("There are %d items in the invertory.\n",cntp);
	printf("The items are:\n\n");
	 printsc(cntp,Store);
	scanf("%d",&op);
}
if(op==7)
{
  printf("\nYou chose to return an item to the store. Please tell us what you want to return and how many.\n\n");

  returnitem(Store,&cntp,Balancepoint);
  	printf("There are %d items in the invertory.\n",cntp);
	printf("The items are:\n\n");
	 printsc(cntp,Store);
	scanf("%d",&op);
}

if(op==8)
{
	
  printf("\nYou chose to sell an item to the store. Please describe the item using the item string format:\nitem name_*_department_*_expiration date in the format mm.dd_*_price in the format xx.yy_*_number of available items of that type\n\n");
  chk=getchar();
  
  Stop(Store[cntp],Store,&cntp,&Balance,1);
  
  
  printf("You successfully sold your product to our store.\n\n\n");
  	printf("There are %d items in the invertory.\n",cntp);
	printf("The items are:\n\n");
	 printsc(cntp,Store);
	scanf("%d",&op);
}
if(op==9)
{
	
	printf("You chose to get rid of all expired items in the inventory. Please enter the present date.\n\n");

	scanf("%s",&date);
	date[5] = '\0';
	datesortarray1(Store,cntp);
	expirationdate(date,Store,&cntp,Balancepoint);

	printf("You successfully removed all the expired items from the inventory.\n\n\n");
		printf("There are %d items in the invertory.\n",cntp);
	printf("The items are:\n");
	 printsc(cntp,Store);
	scanf("%d",&op);
}
if(op==10)
{
  printf("You chose to check the number of possibilities of a shopping basket with your ammount of money. Please tell us how many NIS you have for shopping today.\n\n");
  scanf("%lf",&money);
  j2=get_number_of_possibilities(Store,money,cntp);
  printf("Thanks for coming to our store. With %g NIS we have %d possibilities in our inventory for you to shop.\n\n\n",money,j2);
  	printf("There are %d items in the invertory.\n",cntp);
	printf("The items are:\n\n");
	 printsc(cntp,Store);
	scanf("%d",&op);
}
}
if(op==0)
{
	printf("There are %d items in the invertory.\n",cntp);
	printf("The items are:\n\n");
	for(f;f<cntp;f++)
{
	
	printf("%s_*_",Store[f]->item_name);
	printf("%s_*_",Store[f]->department);
	printf("%s_*_",Store[f]->expiration_date);
	
	printf("%lf_*_",Store[f]->price);
	printf("%d\n",Store[f]->available);
}
	printf("\n\nThe store's balance in the end of the day is %gNIS.\n",*Balancepoint);
}
	
	

}